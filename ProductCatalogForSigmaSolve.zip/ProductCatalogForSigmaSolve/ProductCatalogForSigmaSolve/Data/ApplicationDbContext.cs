﻿using Microsoft.EntityFrameworkCore;
using ProductCatalogForSigmaSolve.Models;

namespace ProductCatalogForSigmaSolve.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Category { get; set; }
    }
}
