﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace ProductCatalogForSigmaSolve.Models
{
    public enum CurrencyEnum
    {
        USD,
        EUR,
        INR,
        GBP
    }

    public class Product
    {
        [Key]
        public int ProductId { get; set; }

        [StringLength(256)]
        public string Name { get; set; }

        [StringLength(6)]
        public string SKU { get; set; }

        [ForeignKey("Category")]
        public int CategoryID { get; set; }

        [DataType(DataType.Currency)]
        public decimal BasePrice { get; set; }

        [DataType(DataType.Currency)]
        public decimal MRP { get; set; }

        public decimal Profit => MRP - BasePrice;

        public string Description { get; set; }

        public CurrencyEnum Currency { get; set; }

        public DateTime ManufacturedDate { get; set; } = DateTime.Today;

        [DataType(DataType.Date)]
        public DateTime ExpiryDate { get; set; }
    }
}
