﻿using ProductCatalogForSigmaSolve.Models;
using ProductCatalogForSigmaSolve.Repositories;

namespace ProductCatalogForSigmaSolve.Services
{
    public interface IProductService
    {
        Task<List<Product>> GetAllProducts();
        Task<Product> GetProductById(int id);
        Task<int> AddProduct(Product product);
        Task<int> UpdateProduct(Product product);
        Task<bool> DeleteProduct(int id);
    }
    public class ProductService : IProductService
    {
        private readonly IProductRepository productRepository;
        public ProductService(IProductRepository _productRepository) 
        {
            productRepository = _productRepository;
        }

        public async Task<List<Product>> GetAllProducts()
        {
            return await productRepository.GetAllProducts();
        }

        public async Task<Product> GetProductById(int id)
        {
            return await productRepository.GetProductById(id);
        }

        public async Task<int> AddProduct(Product product)
        {
            return await productRepository.AddProduct(product); 
        }

        public async Task<int> UpdateProduct(Product product)
        {
            return await productRepository.UpdateProduct(product);
        }

        public async Task<bool> DeleteProduct(int id)
        {
            return await productRepository.DeleteProduct(id);
        }
    }
}
