﻿using Microsoft.EntityFrameworkCore;
using ProductCatalogForSigmaSolve.Data;
using ProductCatalogForSigmaSolve.Models;

namespace ProductCatalogForSigmaSolve.Repositories
{
    public interface IProductRepository
    {
        Task<List<Product>> GetAllProducts();
        Task<Product> GetProductById(int id);
        Task<int> AddProduct(Product product);
        Task<int> UpdateProduct(Product product);
        Task<bool> DeleteProduct(int id);
    }
    public class ProductRepository : IProductRepository
    {
        private readonly ApplicationDbContext context;

        public ProductRepository(ApplicationDbContext _context)
        {
            context = _context;
        }

        public async Task<List<Product>> GetAllProducts()
        {
            return await context.Products.ToListAsync();
        }

        public async Task<Product> GetProductById(int id)
        {
            var data = await context.Products.Where(x => x.ProductId == id).FirstOrDefaultAsync();

            return data;
        }

        public async Task<int> AddProduct(Product product)
        {
            await context.Products.AddAsync(product);
            return await context.SaveChangesAsync();
        }

        public async Task<int> UpdateProduct(Product product)
        {
            context.Products.Update(product);
            return await context.SaveChangesAsync();
        }

        public async Task<bool> DeleteProduct(int id)
        {
            var product = await context.Products.FindAsync(id);
            if (product != null)
            {
                context.Products.Remove(product);
                return await context.SaveChangesAsync() > 0;
            }
            return false;
        }
    }
}
