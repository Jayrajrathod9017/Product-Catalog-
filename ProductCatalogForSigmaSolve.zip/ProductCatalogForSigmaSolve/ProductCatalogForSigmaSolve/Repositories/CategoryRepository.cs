﻿using Microsoft.EntityFrameworkCore;
using ProductCatalogForSigmaSolve.Data;
using ProductCatalogForSigmaSolve.Models;

namespace ProductCatalogForSigmaSolve.Repositories
{
    public interface ICategoryRepository
    {
        Task<List<Category>> GetAllCategories();
    }
    public class CategoryRepository : ICategoryRepository
    {
        private readonly ApplicationDbContext context;
        public CategoryRepository(ApplicationDbContext _context) 
        {
            context = _context;
        }

        public async Task<List<Category>> GetAllCategories()
        {
            return await context.Category.ToListAsync();
        }   
    }
}
